اصلاحات Main.py
- مسیرهای /manifest.json و /sw.js اضافه شد.
- مدیریت اتصال SQLite با contextmanager: commit/rollback و close تضمینی.
- ساخت پوشه مسیر دیتابیس در شروع اتصال.
- فرم ثبت سفارش و پنل مدیریت حفظ شده‌اند.

محتویات را در ریشه مخزن EitaaBot قرار دهید (Main.py جایگزین شود، static شامل دو فایل است).
سپس در Render متغیر DATABASE_PATH را روی /var/data/orders.db تنظیم کنید و Disk با Mount Path=/var/data داشته باشید.
کلیدهای EITAA_TOKEN، EITAA_CHAT_ID و ADMIN_PANEL_KEY فقط در Render Environment باشند؛ داخل GitHub ننویسید.
